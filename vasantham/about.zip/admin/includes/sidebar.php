
<div class="nav-left-sidebar sidebar-dark" style="overflow-y: scroll; height:650px;">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="dashboard.php">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Menu</li>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php"><i class="fa fa-fw fa-user-circle"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw fa-rocket"></i>Property Type</a>
                        <div id="submenu-2" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="add-propertytype.php">Add Property Type </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-propertytype.php">Manage Property Type </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-3"><i class="fas fa-fw fa-chart-pie"></i>State Name</a>
                        <div id="submenu-3" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="add-State Name.php">Add State Name</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-State Name.php">Manage State Name</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-4"><i class="fab fa-fw fa-wpforms"></i>State</a>
                        <div id="submenu-4" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="add-state.php">Add State</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-state.php">Manage State</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-fw fa-table"></i>City</a>
                        <div id="submenu-5" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="add-city.php">Add City</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-city.php">Manage City</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-agents.php"><i class="fas fa-fw fa-file"></i>Agents</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listed-properties.php"><i class="fas fa-fw fa-file"></i>List of Properties</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="approve-properties.php"><i class="fas fa-fw fa-check-circle"></i>Approve Properties</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="all-enquiries.php"><i class="fas fa-fw fa-file"></i>All Enquiries</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="want-to-sell.php"><i class="fas fa-fw fa-file"></i>Want to Sell</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="want-to-buy.php"><i class="fas fa-fw fa-file"></i>Want to Buy</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-banner" aria-controls="submenu-banner"><i class="fas fa-fw fa-image"></i>Banner Management</a>
                        <div id="submenu-banner" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-banners.php">View Banners</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="add-banner.php">Add Banner</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <!-- Blog Management Section -->
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-blog" aria-controls="submenu-blog">
                            <i class="fas fa-fw fa-blog"></i>Blog Management
                        </a>
                        <div id="submenu-blog" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="manage-blogs.php">View Blogs</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="add-blog.php">Add Blog</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-divider">Features</li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-6" aria-controls="submenu-6"><i class="fas fa-fw fa-file"></i> Pages </a>
                        <div id="submenu-6" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="aboutus.php">About Us</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contactus.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search-property.php"><i class="fa fa-fw fa-search"></i>Search Property</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bwdates-reports-ds.php"><i class="fa fa-fw fa-search"></i>Reports</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="url-management.php"><i class="fa fa-fw fa-search"></i>URL Management</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>